# Brand Builder — Recruitment Landing Page

A responsive, single-page recruitment site for an e-commerce brand builder and Shopify page builder role.

## Run locally

```bash
npm install
npm run dev
```

The development server runs on `http://localhost:3000`.

## Production build

```bash
npm run build
npm run preview
```

The deployable static site is generated in `dist/`.

## Upload to GitHub

```bash
git init
git add .
git commit -m "Add brand builder recruitment landing page"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

The Vite configuration uses relative asset paths, so the production build also works on a GitHub Pages project subpath. To publish with GitHub Pages, serve the contents of `dist/` with your preferred Pages workflow.

## Stack

- React + TypeScript + Vite
- Custom responsive CSS
- GSAP + ScrollTrigger for entrance and scroll animation
- Lenis for smooth scrolling
- Lucide for interface icons

The site is frontend-only. It has no database, tracking, form submission service or external application endpoint. The application checklist can be copied or downloaded in the browser.
