import { useEffect, useRef, useState } from 'react'
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Check,
  Copy,
  Download,
  Menu,
  X,
} from 'lucide-react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Lenis from 'lenis'
import '../App.css'

gsap.registerPlugin(ScrollTrigger)

const navItems = [
  { label: 'The role', href: '#role' },
  { label: 'The work', href: '#work' },
  { label: 'The standard', href: '#standard' },
  { label: 'How we work', href: '#process' },
]

const workItems = [
  {
    tag: 'Buyer avatar research',
    title: 'Find the person beneath the purchase.',
    body: 'Dig into what keeps your buyer up at night, what she has already tried, what she is afraid of, and what finally makes her buy. Real research—not educated guesses dressed up as insight.',
  },
  {
    tag: 'Voice of customer',
    title: 'Write in her words, not marketing language.',
    body: 'Mine Reddit threads, Amazon reviews, TikTok comments, Facebook groups and forums for the exact phrases customers use. Turn them into a voice-of-customer document for every brand.',
  },
  {
    tag: 'Brand direction',
    title: 'Give every product a reason to exist.',
    body: 'Define the positioning, tone of voice, story and visual direction. Benchmark the best DTC brands in the category—and be able to explain precisely why their pages work.',
  },
  {
    tag: 'Market analysis',
    title: 'Bring the best ideas home. Make them better.',
    body: 'Study what top brands abroad are doing that nobody in the Netherlands has picked up yet. Find the angles, offers and page structures worth adapting.',
  },
  {
    tag: 'Shopify + Claude',
    title: 'Build the page, not just the presentation.',
    body: 'Use Claude to design and build complete Shopify landing and product pages: long-form, rich in proof, with reviews, comparisons, ingredients, bundles, subscriptions and FAQs.',
  },
  {
    tag: 'Copywriting',
    title: 'Make every sentence earn its place.',
    body: 'Write headlines, product pages, advertorials and email flows in English or Dutch. Dutch is a plus, not a requirement; translation support is available.',
  },
]

const standards = [
  'You can take a product and a short brief, then return with research, brand direction and a finished website—without needing every step explained.',
  'You have real taste. You know the difference between a page that looks “fine” and one that looks like a €10k agency built it.',
  'Your copy sounds like a person. No empty wellness language, no generic slogans, no default AI phrasing.',
  'You give honest input. If the idea is weak, you say so—and show us a stronger one.',
  'You communicate clearly in English, keep your work structured, and share progress without being chased.',
]

const applicationText = `SAFFRON

APPLICATION — BRAND BUILDER & SHOPIFY PAGE BUILDER

1. Two or three websites or landing pages I built or wrote myself:
[Add links]
Tools used: [Add tools]
My part: [Explain your contribution]

2. One real example of buyer avatar or voice-of-customer research:
[Add a document, screenshot or link]

3. Why the Arrae or Norse Organics product page converts well:
[Two or three sentences]

Notes:
- Applications without examples will not be read.
- Start the application with the word SAFFRON.
- Send the finished application through the channel where you found this role.`

function HeroBoard() {
  return (
    <div className="hero-board" aria-hidden="true">
      <div className="board-research">
        <div className="board-meta">VOICE OF CUSTOMER / 001</div>
        <p>“I just want to know if this actually works.”</p>
        <div className="board-sources">REVIEWS&nbsp;&nbsp; REDDIT&nbsp;&nbsp; TIKTOK</div>
      </div>
      <div className="board-brand">
        <div className="board-meta">BRAND DIRECTION</div>
        <div className="board-letter">Aa</div>
        <div className="board-swatches">
          <span />
          <span />
          <span />
        </div>
      </div>
      <div className="board-page">
        <div className="browser-bar">
          <span />
          <span />
          <span />
        </div>
        <div className="product-layout">
          <div className="product-visual">
            <div className="bottle-cap" />
            <div className="bottle">
              <span>EVERY<br />DAY</span>
            </div>
          </div>
          <div className="product-copy">
            <span className="tiny-label">A PAGE WITH A POINT OF VIEW</span>
            <strong>Less noise.<br />More reasons<br />to believe.</strong>
            <span className="fake-line" />
            <span className="fake-line short" />
            <span className="fake-button" />
          </div>
        </div>
      </div>
      <svg className="board-arrow" viewBox="0 0 160 120" fill="none">
        <path className="hero-draw" d="M8 101C39 112 81 91 78 60C75 31 42 27 40 49C38 75 92 83 135 40" />
        <path className="hero-draw" d="M116 41L137 38L140 59" />
      </svg>
    </div>
  )
}

function CopyComparison() {
  const [mode, setMode] = useState<'marketer' | 'customer'>('customer')
  const isCustomer = mode === 'customer'

  return (
    <div className="copy-lab" data-reveal>
      <div className="copy-lab-topline">
        <span>COPY TEST</span>
        <span>ILLUSTRATIVE EXAMPLE</span>
      </div>
      <h3>Which line would you put on the page?</h3>
      <div className="copy-switch" aria-label="Compare copywriting styles">
        <button
          type="button"
          aria-pressed={!isCustomer}
          onClick={() => setMode('marketer')}
        >
          The marketer version
        </button>
        <button
          type="button"
          aria-pressed={isCustomer}
          onClick={() => setMode('customer')}
        >
          The customer version
        </button>
      </div>
      <div className="copy-output" aria-live="polite">
        <blockquote key={mode}>
          {isCustomer
            ? '“I want to know what’s in it, why it works, and whether it’s worth the money.”'
            : '“Unlock your potential and elevate your wellness journey today.”'}
        </blockquote>
        <p>
          {isCustomer
            ? 'Now the page has a job: answer those three questions with evidence.'
            : 'It sounds polished, but it says nothing the customer can hold on to.'}
        </p>
      </div>
    </div>
  )
}

export default function Home() {
  const root = useRef<HTMLDivElement>(null)
  const [menuOpen, setMenuOpen] = useState(false)
  const [navHidden, setNavHidden] = useState(false)
  const [copyStatus, setCopyStatus] = useState('')

  useEffect(() => {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduceMotion) return

    const lenis = new Lenis({ duration: 1.05, smoothWheel: true })
    lenis.on('scroll', ScrollTrigger.update)
    const ticker = (time: number) => lenis.raf(time * 1000)
    gsap.ticker.add(ticker)
    gsap.ticker.lagSmoothing(0)

    const context = gsap.context(() => {
      gsap.set('.hero-reveal', { yPercent: 110 })
      const heroTimeline = gsap.timeline({ defaults: { ease: 'power3.out' } })
      heroTimeline
        .to('.hero-reveal', { yPercent: 0, duration: 0.85, stagger: 0.09 })
        .fromTo(
          '.hero-board',
          { opacity: 0, y: 40, rotate: 2 },
          { opacity: 1, y: 0, rotate: 0, duration: 1 },
          '-=0.55',
        )
        .fromTo(
          '.hero-draw',
          { strokeDasharray: 1200, strokeDashoffset: 1200 },
          { strokeDashoffset: 0, duration: 1.3, stagger: 0.15 },
          '-=0.8',
        )

      gsap.utils.toArray<HTMLElement>('[data-reveal]').forEach((element) => {
        gsap.fromTo(
          element,
          { y: 40, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.85,
            ease: 'power3.out',
            scrollTrigger: { trigger: element, start: 'top 88%', once: true },
          },
        )
      })

      gsap.utils.toArray<SVGPathElement>('.draw-on-scroll').forEach((path) => {
        const length = path.getTotalLength()
        gsap.set(path, { strokeDasharray: length, strokeDashoffset: length })
        gsap.to(path, {
          strokeDashoffset: 0,
          duration: 1.4,
          ease: 'power2.out',
          scrollTrigger: { trigger: path, start: 'top 90%', once: true },
        })
      })

      gsap.to('.hero-board', {
        y: -50,
        ease: 'none',
        scrollTrigger: {
          trigger: '.hero',
          start: 'top top',
          end: 'bottom top',
          scrub: 1,
        },
      })
    }, root)

    return () => {
      context.revert()
      gsap.ticker.remove(ticker)
      lenis.destroy()
    }
  }, [])

  useEffect(() => {
    let previousY = window.scrollY
    const onScroll = () => {
      const currentY = window.scrollY
      if (!menuOpen && currentY > 180 && currentY > previousY + 4) {
        setNavHidden(true)
      } else if (currentY < previousY - 4 || currentY < 180) {
        setNavHidden(false)
      }
      previousY = currentY
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [menuOpen])

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setMenuOpen(false)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [])

  const closeMenu = () => setMenuOpen(false)

  const copyApplication = async () => {
    try {
      await navigator.clipboard.writeText(applicationText)
      setCopyStatus('Application checklist copied.')
    } catch {
      const textArea = document.createElement('textarea')
      textArea.value = applicationText
      textArea.style.position = 'fixed'
      textArea.style.opacity = '0'
      document.body.appendChild(textArea)
      textArea.select()
      const copied = document.execCommand('copy')
      textArea.remove()
      setCopyStatus(copied ? 'Application checklist copied.' : 'Copy failed. Please download the brief instead.')
    }
  }

  const downloadBrief = () => {
    const blob = new Blob([applicationText], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'brand-builder-application-brief.txt'
    document.body.appendChild(link)
    link.click()
    link.remove()
    URL.revokeObjectURL(url)
    setCopyStatus('Application brief downloaded.')
  }

  return (
    <div ref={root} className="site-wrap">
      <a className="skip-link" href="#main-content">Skip to content</a>
      <header className={`site-header ${navHidden ? 'site-header--hidden' : ''}`}>
        <div className="nav-inner page-shell">
          <a className="wordmark" href="#top" onClick={closeMenu} aria-label="Open role, back to top">
            <span>OPEN ROLE</span>
            <span>NL / CET</span>
          </a>
          <nav className="desktop-nav" aria-label="Main navigation">
            {navItems.map((item) => (
              <a key={item.href} href={item.href}>{item.label}</a>
            ))}
          </nav>
          <a className="nav-apply" href="#apply">
            Apply <ArrowUpRight aria-hidden="true" />
          </a>
          <button
            type="button"
            className="menu-toggle"
            aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={menuOpen}
            aria-controls="mobile-navigation"
            onClick={() => setMenuOpen((open) => !open)}
          >
            {menuOpen ? <X aria-hidden="true" /> : <Menu aria-hidden="true" />}
          </button>
        </div>
        <nav
          id="mobile-navigation"
          className={`mobile-nav ${menuOpen ? 'mobile-nav--open' : ''}`}
          aria-label="Mobile navigation"
          aria-hidden={!menuOpen}
        >
          {navItems.map((item) => (
            <a key={item.href} href={item.href} onClick={closeMenu} tabIndex={menuOpen ? 0 : -1}>
              {item.label}<ArrowRight aria-hidden="true" />
            </a>
          ))}
          <a href="#apply" onClick={closeMenu} tabIndex={menuOpen ? 0 : -1}>
            Apply<ArrowRight aria-hidden="true" />
          </a>
        </nav>
      </header>

      <main id="main-content">
        <section className="hero" id="top" aria-labelledby="hero-title">
          <div className="hero-orbit" aria-hidden="true">
            <svg viewBox="0 0 900 500" fill="none" preserveAspectRatio="none">
              <path className="hero-draw" d="M-40 403C171 485 277 157 467 184C652 210 644 467 948 304" />
            </svg>
          </div>
          <div className="page-shell hero-inner">
            <div className="hero-kicker hero-mask">
              <span className="hero-reveal">E-COMMERCE BRAND BUILDER · SHOPIFY · REMOTE</span>
            </div>
            <h1 id="hero-title" className="hero-title">
              <span className="hero-mask hero-line"><span className="hero-reveal">Turn a product</span></span>
              <span className="hero-mask hero-line hero-line--indent"><span className="hero-reveal">into a <em>brand</em></span></span>
              <span className="hero-mask hero-line hero-line--last"><span className="hero-reveal">people buy.</span></span>
            </h1>
            <HeroBoard />
            <div className="hero-bottom">
              <p>
                One person to research the buyer, find the words, shape the brand and build the Shopify page—without waiting for a step-by-step brief.
              </p>
              <a className="button button--paper" href="#apply">
                Show me your work <ArrowDown aria-hidden="true" />
              </a>
            </div>
            <a className="scroll-cue" href="#role" aria-label="Scroll to read about the role">
              <span>READ THE ROLE</span>
              <span className="scroll-line" aria-hidden="true" />
            </a>
          </div>
          <div className="marquee" aria-label="Research, positioning, copywriting, Shopify">
            <div className="marquee-track" aria-hidden="true">
              {[0, 1].map((group) => (
                <div className="marquee-group" key={group}>
                  <span>RESEARCH</span><i>×</i><span>POSITIONING</span><i>×</i><span>COPYWRITING</span><i>×</i><span>SHOPIFY</span><i>×</i>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="role-section section-space" id="role" aria-labelledby="role-title">
          <div className="page-shell editorial-grid">
            <div className="section-label" data-reveal>
              <span>THE ROLE, IN ONE SENTENCE</span>
            </div>
            <div className="role-statement">
              <h2 id="role-title" data-reveal>
                Strategy and execution, in the <em>same pair of hands.</em>
              </h2>
              <div className="role-copy" data-reveal>
                <p>
                  We run several e-commerce brands in the Netherlands—supplements, skincare and home appliances—and launch new ones regularly.
                </p>
                <p>
                  This role is for someone who thinks like a brand builder and can actually ship the website. Not a handoff between five people. One sharp mind, following the idea all the way through.
                </p>
              </div>
            </div>
          </div>
          <div className="page-shell role-principles" data-reveal>
            <div><strong>Think</strong><span>like a brand builder.</span></div>
            <div><strong>Write</strong><span>like a real customer.</span></div>
            <div><strong>Build</strong><span>like it has your name on it.</span></div>
          </div>
        </section>

        <section className="work-section section-space" id="work" aria-labelledby="work-title">
          <div className="page-shell work-grid">
            <div className="work-heading">
              <div className="section-label" data-reveal><span>WHAT YOU WILL DO</span></div>
              <h2 id="work-title" data-reveal>From “what is this?” to “I need this.”</h2>
              <svg className="work-connector" viewBox="0 0 240 250" fill="none" aria-hidden="true">
                <path className="draw-on-scroll" d="M12 18C121 1 216 43 173 104C133 161 34 91 48 169C57 220 142 238 222 198" />
                <path className="draw-on-scroll" d="M199 190L225 197L216 222" />
              </svg>
            </div>
            <div className="work-list">
              {workItems.map((item) => (
                <article className="work-item" key={item.tag} data-reveal>
                  <span className="work-tag">{item.tag}</span>
                  <div>
                    <h3>{item.title}</h3>
                    <p>{item.body}</p>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="tools-section section-space" aria-labelledby="tools-title">
          <div className="page-shell">
            <div className="tools-heading" data-reveal>
              <div className="section-label"><span>YOUR WORKING TOOLKIT</span></div>
              <h2 id="tools-title">Know the tools.<br /><em>Don’t hide behind them.</em></h2>
              <p>Claude is your main working tool. Taste, judgment and follow-through are still yours.</p>
            </div>
            <div className="tool-list">
              <div className="tool-row" data-reveal>
                <h3>Claude</h3>
                <p>Research, writing, generating and editing website code and Shopify sections. Prompt well, iterate hard, fix what breaks.</p>
                <span>ESSENTIAL</span>
              </div>
              <div className="tool-row" data-reveal>
                <h3>Shopify</h3>
                <p>Themes, sections, product pages, apps and enough Liquid confidence to get in, make the change and get out.</p>
                <span>ESSENTIAL</span>
              </div>
              <div className="tool-row" data-reveal>
                <h3>Figma <small>/ Canva</small></h3>
                <p>Mood boards and brand guides that make the visual direction clear before the page build begins.</p>
                <span>ESSENTIAL</span>
              </div>
            </div>
            <div className="bonus-tools" data-reveal>
              <span>USEFUL, NOT DEAL-BREAKERS</span>
              <p>Meta Ads · Klaviyo · Notion · Basic HTML/CSS · Nano Banana · Midjourney</p>
            </div>
          </div>
        </section>

        <section className="standard-section section-space" id="standard" aria-labelledby="standard-title">
          <div className="page-shell standard-grid">
            <div className="standard-content">
              <div className="section-label" data-reveal><span>WHAT GOOD LOOKS LIKE</span></div>
              <h2 id="standard-title" data-reveal>The standard is taste.<br />The test is whether it <em>works.</em></h2>
              <div className="standards-list">
                {standards.map((standard) => (
                  <div className="standard-item" key={standard} data-reveal>
                    <Check aria-hidden="true" />
                    <p>{standard}</p>
                  </div>
                ))}
              </div>
              <p className="language-note" data-reveal>Strong English is essential. Dutch is a bonus, not a barrier.</p>
            </div>
            <CopyComparison />
          </div>
        </section>

        <section className="process-section section-space" id="process" aria-labelledby="process-title">
          <div className="page-shell">
            <div className="category-line" data-reveal>
              <span>SUPPLEMENTS</span><span>SKINCARE</span><span>HOME APPLIANCES</span><span>WHAT’S NEXT</span>
            </div>
            <div className="process-heading">
              <div className="section-label" data-reveal><span>HOW WE WORK</span></div>
              <h2 id="process-title" data-reveal>Start with one page.<br /><em>Build from there.</em></h2>
            </div>
            <div className="process-list">
              <div className="process-item" data-reveal>
                <span>THE START</span>
                <h3>A small paid test project</h3>
                <p>Buyer research plus one product page. Enough to see how you think, write and build.</p>
              </div>
              <div className="process-item" data-reveal>
                <span>IF IT’S GOOD</span>
                <h3>Steady, long-term work</h3>
                <p>Multiple brands and regular launches mean there is always another brand to build.</p>
              </div>
              <div className="process-item" data-reveal>
                <span>THE RHYTHM</span>
                <h3>Flexible hours, reachable weekdays</h3>
                <p>Netherlands time (CET). Clear updates, structured communication, no chasing required.</p>
              </div>
              <div className="process-item" data-reveal>
                <span>THE SYSTEM</span>
                <h3>Simple, shared tools</h3>
                <p>WhatsApp or Slack for communication. Google Drive and Notion for files and documentation.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="apply-section section-space" id="apply" aria-labelledby="apply-title">
          <div className="apply-scribble" aria-hidden="true">
            <svg viewBox="0 0 500 180" fill="none">
              <path className="draw-on-scroll" d="M21 113C91 7 379 7 461 78C535 143 145 184 45 132C-22 96 203 25 478 111" />
            </svg>
          </div>
          <div className="page-shell apply-inner">
            <div className="section-label" data-reveal><span>HOW TO APPLY</span></div>
            <h2 id="apply-title" data-reveal>Don’t just tell me.<br /><em>Show me how you think.</em></h2>
            <ol className="application-list">
              <li data-reveal>
                <span>01</span>
                <h3>Your pages</h3>
                <p>Send two or three websites or landing pages you built or wrote. Include the links, the tools you used and exactly which part was yours.</p>
              </li>
              <li data-reveal>
                <span>02</span>
                <h3>Your research</h3>
                <p>Share one real buyer avatar or voice-of-customer example. A document, screenshot or anything that shows the actual work.</p>
              </li>
              <li data-reveal>
                <span>03</span>
                <h3>Your thinking</h3>
                <p>In two or three sentences, explain why the Arrae or Norse Organics product page converts well. Short is good. Specific is better.</p>
              </li>
            </ol>
            <div className="saffron-note" data-reveal>
              <p>Start your application with the word</p>
              <strong>SAFFRON</strong>
              <p>Applications without examples won’t be read.</p>
            </div>
            <div className="application-actions" data-reveal>
              <button type="button" className="button button--paper" onClick={copyApplication}>
                <Copy aria-hidden="true" /> Copy application checklist
              </button>
              <button type="button" className="button button--outline" onClick={downloadBrief}>
                <Download aria-hidden="true" /> Download the brief
              </button>
            </div>
            <p className="application-note" data-reveal>
              Add your examples, then send the finished application through the channel where you found this role.
            </p>
            <p className="copy-status" role="status" aria-live="polite">{copyStatus}</p>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="page-shell footer-inner">
          <p>Research with curiosity.<br />Write with precision.<br />Build with taste.</p>
          <a href="#top">Back to top <ArrowUpRight aria-hidden="true" /></a>
          <span>OPEN ROLE · NETHERLANDS / CET</span>
        </div>
      </footer>
    </div>
  )
}
